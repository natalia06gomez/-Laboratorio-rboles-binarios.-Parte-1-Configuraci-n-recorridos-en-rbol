1.	¿Es posible lograr el mismo resultado con el pre-orden y pos-orden?
2.	¿Es posible lograr el mismo resultado con el in-orden y pos-orden?

