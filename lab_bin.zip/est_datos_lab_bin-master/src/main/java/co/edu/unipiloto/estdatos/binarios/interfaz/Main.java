package co.edu.unipiloto.estdatos.binarios.interfaz;

public class Main{
  
	public static void main(String[] args){
    
		new ArbolCLI().mainMenu();

	}
}
